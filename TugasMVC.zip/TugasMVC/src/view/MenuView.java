/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

/**
 *
 * @author dwirizki
 */

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MenuView extends JFrame {

    JLabel welcome;

    JButton btnKendaraan = new JButton("Data Kendaraan");
    JButton btnSopir = new JButton("Data Sopir");
    JButton btnLogout = new JButton("Logout");

    public MenuView(String user) {

        setTitle("MENU");
        setSize(400,300);
        setLayout(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        welcome = new JLabel("Selamat Datang, " + user + "!");

        add(welcome);
        add(btnKendaraan);
        add(btnSopir);
        add(btnLogout);

        welcome.setBounds(100,30,250,30);

        btnKendaraan.setBounds(100,80,180,35);
        btnSopir.setBounds(100,130,180,35);
        btnLogout.setBounds(100,180,180,35);

        btnKendaraan.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                new KendaraanView();
            }
        });

        btnSopir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                new SopirView();
            }
        });

        btnLogout.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                new LoginView();
                dispose();
            }
        });

        setVisible(true);
    }
}