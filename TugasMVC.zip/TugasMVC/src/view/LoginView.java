/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

/**
 *
 * @author dwirizki
 */


import connection.Koneksi;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class LoginView extends JFrame {

    JLabel luser = new JLabel("Username");
    JLabel lpass = new JLabel("Password");

    JTextField tfUser = new JTextField();
    JPasswordField tfPass = new JPasswordField();

    JButton btnLogin = new JButton("LOGIN");

    public LoginView() {

        setTitle("LOGIN");
        setSize(350,250);
        setLayout(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        add(luser);
        add(lpass);
        add(tfUser);
        add(tfPass);
        add(btnLogin);

        luser.setBounds(30,40,100,30);
        tfUser.setBounds(130,40,150,30);

        lpass.setBounds(30,90,100,30);
        tfPass.setBounds(130,90,150,30);

        btnLogin.setBounds(100,150,120,35);

        btnLogin.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                login();
            }
        });

        setVisible(true);
    }

    private void login() {

        try {

            String username = tfUser.getText();
            String password = tfPass.getText();

            if(username.isEmpty() || password.isEmpty()) {

                JOptionPane.showMessageDialog(null,
                        "Field tidak boleh kosong");

                return;
            }

            Connection conn = Koneksi.getConnection();

            String sql = "SELECT * FROM users WHERE username=? AND password=?";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setString(1, username);
            ps.setString(2, password);

            ResultSet rs = ps.executeQuery();

            if(rs.next()) {

                JOptionPane.showMessageDialog(null,
                        "Login Berhasil");

                new MenuView(username);

                dispose();

            } else {

                JOptionPane.showMessageDialog(null,
                        "Username atau Password salah");
            }

        } catch (Exception e) {

            JOptionPane.showMessageDialog(null,
                    e.getMessage());
        }
    }
}