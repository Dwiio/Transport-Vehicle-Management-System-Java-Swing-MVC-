/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

/**
 *
 * @author dwirizki
 */

import connection.Koneksi;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.*;

public class KendaraanView extends JFrame {

    JTextField tfId = new JTextField();
    JTextField tfPlat = new JTextField();
    JTextField tfMerk = new JTextField();
    JTextField tfCari = new JTextField();

    JComboBox cbJenis = new JComboBox(
            new String[]{"Truk","Pick-up","Van"});

    JButton btnTambah = new JButton("Tambah");
    JButton btnEdit = new JButton("Edit");
    JButton btnHapus = new JButton("Hapus");
    JButton btnCari = new JButton("Cari");
    JButton btnKembali = new JButton("Kembali");

    JTable table = new JTable();
    JScrollPane scroll = new JScrollPane(table);

    public KendaraanView() {

        setTitle("DATA KENDARAAN");
        setSize(700,500);
        setLayout(null);
        setLocationRelativeTo(null);

        add(new JLabel("ID")).setBounds(20,20,100,25);
        add(tfId).setBounds(120,20,150,25);

        add(new JLabel("Plat")).setBounds(20,60,100,25);
        add(tfPlat).setBounds(120,60,150,25);

        add(new JLabel("Jenis")).setBounds(20,100,100,25);
        add(cbJenis).setBounds(120,100,150,25);

        add(new JLabel("Merk")).setBounds(20,140,100,25);
        add(tfMerk).setBounds(120,140,150,25);

        add(btnTambah).setBounds(320,20,100,30);
        add(btnEdit).setBounds(430,20,100,30);
        add(btnHapus).setBounds(540,20,100,30);

        add(tfCari).setBounds(320,70,200,30);
        add(btnCari).setBounds(530,70,100,30);

        add(btnKembali).setBounds(540,110,100,30);

        add(scroll).setBounds(20,200,620,220);

        tampilData();

        btnTambah.addActionListener(e -> tambah());
        btnEdit.addActionListener(e -> edit());
        btnHapus.addActionListener(e -> hapus());
        btnCari.addActionListener(e -> cari());

        btnKembali.addActionListener(e -> {

            new MenuView("admin");
            dispose();
        });

        table.addMouseListener(new java.awt.event.MouseAdapter() {

            public void mouseClicked(java.awt.event.MouseEvent evt) {

                int row = table.getSelectedRow();

                tfId.setText(table.getValueAt(row,0).toString());
                tfPlat.setText(table.getValueAt(row,1).toString());
                cbJenis.setSelectedItem(table.getValueAt(row,2).toString());
                tfMerk.setText(table.getValueAt(row,3).toString());
            }
        });

        setVisible(true);
    }

    private void tampilData() {

        DefaultTableModel model = new DefaultTableModel();

        model.addColumn("ID");
        model.addColumn("Plat");
        model.addColumn("Jenis");
        model.addColumn("Merk");

        try {

            Connection conn = Koneksi.getConnection();

            Statement st = conn.createStatement();

            ResultSet rs = st.executeQuery("SELECT * FROM kendaraan");

            while(rs.next()) {

                model.addRow(new Object[]{
                        rs.getString("id"),
                        rs.getString("plat_nomor"),
                        rs.getString("jenis"),
                        rs.getString("merk")
                });
            }

            table.setModel(model);

        } catch (Exception e) {

            System.out.println(e.getMessage());
        }
    }

    private void tambah() {

        try {

            if(tfPlat.getText().isEmpty()
                    || tfMerk.getText().isEmpty()) {

                JOptionPane.showMessageDialog(null,
                        "Data tidak boleh kosong");

                return;
            }

            Connection conn = Koneksi.getConnection();

            String sql = "INSERT INTO kendaraan VALUES(null,?,?,?)";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setString(1, tfPlat.getText());
            ps.setString(2, cbJenis.getSelectedItem().toString());
            ps.setString(3, tfMerk.getText());

            ps.executeUpdate();

            JOptionPane.showMessageDialog(null,
                    "Tambah berhasil");

            tampilData();

        } catch (Exception e) {

            JOptionPane.showMessageDialog(null,
                    e.getMessage());
        }
    }

    private void edit() {

        try {

            Connection conn = Koneksi.getConnection();

            String sql = "UPDATE kendaraan SET plat_nomor=?, jenis=?, merk=? WHERE id=?";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setString(1, tfPlat.getText());
            ps.setString(2, cbJenis.getSelectedItem().toString());
            ps.setString(3, tfMerk.getText());
            ps.setString(4, tfId.getText());

            ps.executeUpdate();

            JOptionPane.showMessageDialog(null,
                    "Edit berhasil");

            tampilData();

        } catch (Exception e) {

            JOptionPane.showMessageDialog(null,
                    e.getMessage());
        }
    }

    private void hapus() {

        try {

            Connection conn = Koneksi.getConnection();

            String sql = "DELETE FROM kendaraan WHERE id=?";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setString(1, tfId.getText());

            ps.executeUpdate();

            JOptionPane.showMessageDialog(null,
                    "Hapus berhasil");

            tampilData();

        } catch (Exception e) {

            JOptionPane.showMessageDialog(null,
                    e.getMessage());
        }
    }

    private void cari() {

        DefaultTableModel model = new DefaultTableModel();

        model.addColumn("ID");
        model.addColumn("Plat");
        model.addColumn("Jenis");
        model.addColumn("Merk");

        try {

            Connection conn = Koneksi.getConnection();

            String sql = "SELECT * FROM kendaraan WHERE plat_nomor LIKE ? OR merk LIKE ?";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setString(1,
                    "%" + tfCari.getText() + "%");

            ps.setString(2,
                    "%" + tfCari.getText() + "%");

            ResultSet rs = ps.executeQuery();

            while(rs.next()) {

                model.addRow(new Object[]{
                        rs.getString("id"),
                        rs.getString("plat_nomor"),
                        rs.getString("jenis"),
                        rs.getString("merk")
                });
            }

            table.setModel(model);

        } catch (Exception e) {

            JOptionPane.showMessageDialog(null,
                    e.getMessage());
        }
    }
}